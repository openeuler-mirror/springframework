
/**
 *
 * Support package for annotation-driven bean configuration.
 *
 */
package org.springframework.beans.factory.annotation;

